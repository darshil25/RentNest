--
-- Database: `dummydata`
--
CREATE DATABASE IF NOT EXISTS `dummydata` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `dummydata`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminId` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `name` varchar(20) NOT NULL,
  `profile` varchar(30) NOT NULL,
  `mobileNumber` varchar(15) NOT NULL,
  `roleId` int(11) NOT NULL,
  `companyId` varchar(100) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `delete` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminId`, `email`, `password`, `name`, `profile`, `mobileNumber`, `roleId`, `companyId`, `status`, `created`, `updated`, `delete`) VALUES
(1, 'rohansmart333@gmail.com', '04d225ce1e6d959c725fa5a0feaf1609', 'Rohan', 'profile-1688623897.jpg', '9426449988', 1, '1', 0, '2021-12-11 11:57:56', '2023-07-07 04:09:38', 0),
(2, 'waitlift@gmail.com', '04d225ce1e6d959c725fa5a0feaf1609', 'Wait Lift', 'profile-1689838228.png', '9876543210', 1, '1', 0, '2023-07-06 06:14:24', '2023-07-20 07:30:28', 0),
(3, 'test@gmail.com', '04d225ce1e6d959c725fa5a0feaf1609', 'Test edit', '', '9876543210', 2, '1', 0, '2023-07-07 04:31:44', '2023-07-08 06:46:25', 0),
(4, 't@gmail.com', '0e7517141fb53f21ee439b355b5a1d0a', 'dipesh', '', '7655235946', 2, NULL, 0, '2023-07-18 12:05:54', '2023-07-24 11:26:51', 0);

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

CREATE TABLE `equipment` (
  `equipmentId` int(11) NOT NULL,
  `equipmentName` varchar(50) NOT NULL,
  `modalType` varchar(50) NOT NULL,
  `duration` varchar(30) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `delete` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `equipment`
--

INSERT INTO `equipment` (`equipmentId`, `equipmentName`, `modalType`, `duration`, `created`, `updated`, `delete`) VALUES
(1, '', '56', '30:00', '2023-07-18 13:06:14', '2023-07-18 13:24:54', 1),
(2, 'Ht', 'Dfd', 'fdf df', '2023-07-18 13:11:30', '2023-07-18 13:11:30', 0),
(3, 'Dfdh', 'Dfdfd', 'dfsdf', '2023-07-18 13:14:47', '2023-07-20 06:17:23', 1),
(4, '', '', '', '2023-07-18 13:25:02', '2023-07-18 13:29:51', 1),
(5, 'Httt', 'Dfd', 'fdfd', '2023-07-18 13:29:55', '2023-07-18 13:34:20', 0),
(6, 'Time', '', '30:00', '2023-07-18 13:37:17', '2023-07-18 13:37:17', 0),
(7, 'Yt', 'Not defina%&', 'tyrt', '2023-07-18 13:38:11', '2023-07-20 07:34:16', 0),
(8, 'E', '', 'r', '2023-07-18 13:39:17', '2023-07-18 13:39:17', 0),
(9, 'Gt', 'Rt', 'fg', '2023-07-18 13:40:28', '2023-07-20 06:08:57', 1),
(10, 'Dfdhjhj', '56', '30:00', '2023-07-20 06:05:03', '2023-07-20 06:05:03', 0),
(11, 'Dd', 'Dfd', '30:45', '2023-07-20 06:08:24', '2023-07-20 06:08:24', 0),
(12, '', '', '', '2023-07-24 08:17:14', '2023-07-24 13:26:05', 1);

-- --------------------------------------------------------

--
-- Table structure for table `gym`
--

CREATE TABLE `gym` (
  `gymId` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobileNumber` varchar(12) NOT NULL,
  `email` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `address` varchar(100) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `delete` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `gym`
--

INSERT INTO `gym` (`gymId`, `name`, `mobileNumber`, `email`, `city`, `address`, `created`, `updated`, `delete`) VALUES
(1, 'Abc', '2756795152', 'm@gmail.com', 'junagadh', '', '2023-07-24 08:24:24', '2023-07-24 09:37:44', 0),
(2, 'Abc', '6548526515', 't@gmail.com', 'junagadh', '', '2023-07-24 09:22:31', '2023-07-24 09:25:40', 1),
(3, 'MY GYM', '9574932158', 'my@gmail.com', 'keshod', '', '2023-07-24 10:21:24', '2023-07-24 10:21:24', 0),
(4, 'Er', '6548526515', 'v@g', 'vanthali', 'sardar bag niyar', '2023-07-24 10:56:55', '2023-07-24 10:56:55', 0);

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `menuId` int(11) NOT NULL,
  `mainMenuId` int(11) NOT NULL,
  `menuName` varchar(100) NOT NULL,
  `path` varchar(100) NOT NULL,
  `icon` varchar(100) NOT NULL,
  `order` int(11) NOT NULL,
  `add` varchar(4) NOT NULL,
  `edit` varchar(4) NOT NULL,
  `view` varchar(4) NOT NULL,
  `visibility` varchar(4) NOT NULL,
  `delete` varchar(4) NOT NULL,
  `addPath` varchar(100) NOT NULL,
  `deleteMenu` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`menuId`, `mainMenuId`, `menuName`, `path`, `icon`, `order`, `add`, `edit`, `view`, `visibility`, `delete`, `addPath`, `deleteMenu`) VALUES
(1, 0, 'Dashboard', '../dashboard/', 'dashboard', 1, 'NO', 'NO', 'YES', '', 'NO', '', 0),
(2, 0, 'Utility', '', 'format_list_bulleted\r\n', 2, 'NO', 'NO', 'NO', '', 'NO', '', 0),
(3, 0, 'Master', '', 'dashboard', 3, 'NO', 'NO', 'YES', '', 'NO', '', 0),
(4, 2, 'Admin', '../viewadmin/', '', 1, 'YES', 'YES', 'YES', '', 'YES', '../addadmin/', 0),
(5, 2, 'Role', '../viewrole/', '', 2, 'YES', 'YES', 'YES', '', 'YES', '../addrole/', 0),
(6, 3, 'Equipment', '../viewequipment/', '', 1, 'YES', 'YES', 'YES', '', 'YES', '../addequipment/', 0),
(7, 0, 'GYM', '../viewgym/', 'fitness_center', 4, 'YES', 'YES', 'YES', '', 'YES', '../addgym/', 0);

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `roleId` int(11) NOT NULL,
  `roleName` varchar(30) NOT NULL,
  `encryptId` varchar(30) NOT NULL,
  `menuIdAdd` text NOT NULL,
  `menuIdEdit` text NOT NULL,
  `menuIdDelete` text NOT NULL,
  `menuIdView` text NOT NULL,
  `delete` tinyint(4) NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`roleId`, `roleName`, `encryptId`, `menuIdAdd`, `menuIdEdit`, `menuIdDelete`, `menuIdView`, `delete`, `created`, `updated`) VALUES
(1, 'Super Admin', 'MQ==', '7,16,11,6,10,15,14,3,4', '7,16,11,12,6,10,15,14,3,4', '7,16,11,12,13,6,10,15,14,3,4', '1,7,16,5,2,11,12,13,6,10,15,14,3,4', 0, '2021-11-30 16:04:51', '2022-12-06 13:47:28'),
(2, 'Admin', 'Mg==', '3,4', '3,4', '3,4', '1,2,3,4', 0, '2021-11-30 16:04:51', '2023-07-06 16:56:00'),
(4, 'Developer', 'NA==', '2', '2', '', '1,2', 1, '2021-11-30 16:04:51', '2022-12-06 13:47:28'),
(11, ' Developer', '', '', '', '', '1,2,3,4', 1, '2022-08-05 10:15:26', '2022-12-06 13:47:28'),
(10, 'TEST', '', '', '', '', '', 1, '2022-08-05 10:15:13', '2022-12-06 13:47:28'),
(12, 'Editor ', '', '14,4', '8,5', '', '1,8,5,2,14,3,4', 0, '2022-12-13 15:20:00', '2022-12-13 15:23:18'),
(13, 'Sub editor', '', '', '', '', '', 1, '2022-12-13 15:28:43', '2022-12-13 15:31:48'),
(14, 'ac', '', '', '', '', '', 0, '2023-07-18 17:38:08', '2023-07-18 17:38:08');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userId` int(11) NOT NULL,
  `appVersion` int(11) NOT NULL,
  `googleAddress` varchar(160) DEFAULT NULL,
  `latitude` decimal(10,0) NOT NULL DEFAULT 0,
  `longitude` float NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userId`, `appVersion`, `googleAddress`, `latitude`, `longitude`) VALUES
(0, 10, 'jfdWHJFKJSHGFKJS', 131432, 1564770);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminId`);

--
-- Indexes for table `equipment`
--
ALTER TABLE `equipment`
  ADD PRIMARY KEY (`equipmentId`);

--
-- Indexes for table `gym`
--
ALTER TABLE `gym`
  ADD PRIMARY KEY (`gymId`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`menuId`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`roleId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adminId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `equipment`
--
ALTER TABLE `equipment`
  MODIFY `equipmentId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `gym`
--
ALTER TABLE `gym`
  MODIFY `gymId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `menuId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `roleId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
