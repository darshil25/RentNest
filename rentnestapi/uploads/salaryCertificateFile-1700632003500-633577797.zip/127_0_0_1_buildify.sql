-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 22, 2023 at 04:42 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `buildify`
--
CREATE DATABASE IF NOT EXISTS `buildify` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `buildify`;

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE `content` (
  `contentId` int(11) NOT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` text DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `delete` int(11) NOT NULL DEFAULT 0,
  `delete2` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `credential`
--

CREATE TABLE `credential` (
  `credentialId` int(11) NOT NULL,
  `paymentMode` enum('Test','Live') NOT NULL DEFAULT 'Test',
  `testSecretKey` text DEFAULT NULL,
  `liveSecretKey` text DEFAULT NULL,
  `testPublicKey` text DEFAULT NULL,
  `livePublicKey` text DEFAULT NULL,
  `FCMkey` text DEFAULT NULL,
  `mapKey` text DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dbbackup`
--

CREATE TABLE `dbbackup` (
  `dbbackupId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT '0',
  `url` text NOT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fcmtoken`
--

CREATE TABLE `fcmtoken` (
  `fcmtokenId` int(11) NOT NULL,
  `userId` varchar(6) DEFAULT NULL,
  `token` text DEFAULT NULL,
  `os` varchar(60) DEFAULT NULL,
  `osVersion` varchar(60) DEFAULT NULL,
  `device` varchar(60) DEFAULT NULL,
  `appVersion` varchar(60) DEFAULT NULL,
  `delete` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `notification` int(11) NOT NULL,
  `userId` int(11) NOT NULL DEFAULT 0,
  `emergencyId` int(11) NOT NULL DEFAULT 0,
  `title` text DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `delete` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `settingsId` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `value` text DEFAULT NULL,
  `delete` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userId` int(11) NOT NULL,
  `token` varchar(30) DEFAULT NULL,
  `userCode` varchar(50) DEFAULT NULL,
  `fullName` varchar(50) DEFAULT NULL,
  `firstName` varchar(60) DEFAULT NULL,
  `lastName` varchar(20) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `mobileNumber` varchar(50) DEFAULT NULL,
  `accountType` enum('OWNER','BUILDER','SUBCONTRACTOR') NOT NULL DEFAULT 'OWNER',
  `isProfileComplete` int(11) NOT NULL DEFAULT 0 COMMENT '0=pending \r\n1=\r Completed ',
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `delete` int(11) NOT NULL DEFAULT 0,
  `isVerified` int(11) NOT NULL DEFAULT 0,
  `notification` int(1) NOT NULL DEFAULT 1,
  `block` int(1) NOT NULL DEFAULT 0,
  `updated` datetime NOT NULL DEFAULT current_timestamp(),
  `rejectionReason` text DEFAULT NULL,
  `document` text DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `otp` varchar(6) DEFAULT NULL,
  `completedSteps` text DEFAULT NULL,
  `profilePicture` varchar(150) DEFAULT NULL,
  `cacheImage` varchar(150) DEFAULT NULL,
  `createdBy` int(11) NOT NULL DEFAULT 0,
  `deleteBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `regOs` enum('ANDROID','IOS','ADMIN') DEFAULT NULL,
  `regOsVersion` varchar(15) DEFAULT NULL,
  `regDevice` varchar(30) DEFAULT NULL,
  `loginOs` enum('ANDROID','IOS') DEFAULT NULL,
  `loginOsVersion` varchar(15) DEFAULT NULL,
  `loginDevice` varchar(30) DEFAULT NULL,
  `registeredAppVersion` varchar(10) DEFAULT NULL,
  `loginAppVersion` varchar(10) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT '0',
  `longitude` varchar(255) DEFAULT '0',
  `businessName` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userId`, `token`, `userCode`, `fullName`, `firstName`, `lastName`, `email`, `password`, `mobileNumber`, `accountType`, `isProfileComplete`, `created`, `delete`, `isVerified`, `notification`, `block`, `updated`, `rejectionReason`, `document`, `dob`, `otp`, `completedSteps`, `profilePicture`, `cacheImage`, `createdBy`, `deleteBy`, `updatedBy`, `regOs`, `regOsVersion`, `regDevice`, `loginOs`, `loginOsVersion`, `loginDevice`, `registeredAppVersion`, `loginAppVersion`, `latitude`, `longitude`, `businessName`) VALUES
(7, '158f57836b002274affe', NULL, NULL, NULL, NULL, 'xpertlab.itachi@gmail.com', '202cb962ac59075b964b07152d234b70', NULL, 'SUBCONTRACTOR', 0, '2023-11-17 17:13:01', 0, 0, 1, 0, '2023-11-17 17:13:01', NULL, NULL, NULL, '3986', '[{\"accountType\":true,\"accountInfo\":false,\"businessDetails\":false}]', '1700221381089.png', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`contentId`);

--
-- Indexes for table `credential`
--
ALTER TABLE `credential`
  ADD PRIMARY KEY (`credentialId`);

--
-- Indexes for table `dbbackup`
--
ALTER TABLE `dbbackup`
  ADD PRIMARY KEY (`dbbackupId`);

--
-- Indexes for table `fcmtoken`
--
ALTER TABLE `fcmtoken`
  ADD PRIMARY KEY (`fcmtokenId`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`notification`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`settingsId`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `content`
--
ALTER TABLE `content`
  MODIFY `contentId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `credential`
--
ALTER TABLE `credential`
  MODIFY `credentialId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dbbackup`
--
ALTER TABLE `dbbackup`
  MODIFY `dbbackupId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fcmtoken`
--
ALTER TABLE `fcmtoken`
  MODIFY `fcmtokenId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `notification` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `settingsId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
