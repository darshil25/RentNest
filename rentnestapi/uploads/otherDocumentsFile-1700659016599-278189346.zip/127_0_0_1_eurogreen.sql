--
-- Database: `eurogreen`
--
CREATE DATABASE IF NOT EXISTS `eurogreen` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `eurogreen`;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedbackId` int(11) NOT NULL,
  `firstName` varchar(20) NOT NULL,
  `lastName` varchar(20) NOT NULL,
  `email` varchar(60) NOT NULL,
  `description` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `delete` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feedbackId`, `firstName`, `lastName`, `email`, `description`, `created`, `delete`) VALUES
(1, 'abc', 'abc', 'abc333@gmail.com', 'tetste', '2023-07-21 07:10:59', 0),
(2, 'test', 'Abc', 'abc123@gmail.com', 'feedback test', '2023-07-21 07:11:27', 0),
(3, 'test', 'Abc', 'abc123@gmail.com', 'feedback test', '2023-07-21 07:11:54', 0),
(4, 'Test', 'Testt', 'abc@gmail.com', 'testt', '2023-07-21 07:20:52', 0),
(5, 'Test', 'Testt', 'abc@gmail.com', 'testt', '2023-07-21 07:21:13', 0),
(6, 'Test', 'Testt', 'abc@gmail.com', 'testt', '2023-07-21 07:29:59', 0),
(7, 'Test', 'Testt', 'abc@gmail.com', 'testt', '2023-07-21 07:31:19', 0),
(8, 'Test', 'Testt', 'abc@gmail.com', 'testt', '2023-07-21 07:32:58', 0),
(9, 'Test', 'Testt', 'abc@gmail.com', 'testt', '2023-07-21 07:33:12', 0),
(10, 'Abcd', 'Abcd', 'abc333@gmail.com', 'test', '2023-07-21 07:34:56', 0),
(11, 'Dsa', 'Das', 'test23@gmail.com', 'feed', '2023-07-21 07:36:21', 0),
(12, 'Abcd', 'Test', 'abc44@gmail.com', 'feed back', '2023-07-21 07:41:02', 0),
(13, 'Abcd', 'Test', 'abc44@gmail.com', 'feed back', '2023-07-21 07:41:44', 0),
(14, 'Abcd', 'Test', 'abc44@gmail.com', 'feed back', '2023-07-21 07:43:22', 0),
(15, 'Test', 'Abc', 'abc111@gmail.com', 'test', '2023-07-21 07:44:22', 0),
(16, 'Test', 'Abc', 'abc111@gmail.com', 'test', '2023-07-21 07:45:23', 0),
(17, 'Testing', 'Abcd', 'abcd@gmail.com', 'dsdsaa', '2023-07-21 07:46:52', 0),
(18, 'Ddd', 'Aaa', 'aaa@gmail.com', 'ttest', '2023-07-21 07:48:36', 0);

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `postId` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `imageUrl` varchar(100) NOT NULL,
  `adminId` int(11) NOT NULL,
  `postDate` date DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `delete` tinyint(4) NOT NULL DEFAULT 0,
  `createdBy` tinyint(4) NOT NULL DEFAULT 0,
  `updatedBy` tinyint(4) NOT NULL DEFAULT 0,
  `deleteBy` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`postId`, `title`, `description`, `imageUrl`, `adminId`, `postDate`, `created`, `updated`, `delete`, `createdBy`, `updatedBy`, `deleteBy`) VALUES
(1, 'Office cleaning', 'Our fully insured and bonded office cleaning professionals will provide thorough\nsurface cleaning of all areas including computers, desk tops, counters, files,\npartitions - all surfaces will be wiped clean. The office cleaning service also\nincludes general cleaning in kitchen area, perfect cleaning of lavatory facilities\nincluding replenishing toiletries, soaps, C fold towels, etc., and we will remove\ntrash from all areas and replace liners.\nOur office cleaning service can also provide specialized cleanings, including postconstruction, post –renovation, after paint cleaning, moving in and moving out\noffice cleaning, plus other heavy cleaning services.', 'cleaning-office.jpg', 1, '2023-07-18', '2023-07-18 12:18:31', '2023-07-20 10:48:48', 0, 0, 0, 0),
(2, 'Carpet Cleaning', 'Our professional carpet cleaning staff uses state-of-the-art equipment, supplies\nand techniques, including deodorizing, disinfecting and scotch guarding.\nOur fully bonded and insured, courteous and professional carpet cleaning staff\nwill carefully move all furniture as required, and will treat your possessions with\nthe utmost care.\nOur office carpet cleaning team is well trained to work around your computer\nsystems and business machines, carefully moving only what they must, and\nreturning your place of business to the order in which they found it when the\ncarpet cleaning is completed.\nWe also provide industrial carpet cleaning services. Our industrial level carpet\ncleaning equipment, and our trained staff of industrial cleaning experts, will\nthoroughly and carefully clean carpets in any industrial environment.', 'carpet-cleaning.jpg', 1, '2023-07-18', '2023-07-18 12:44:20', '2023-07-20 10:51:11', 0, 0, 0, 0),
(3, ' Move In Cleaning Services', 'We provide a special move in cleaning service to make your new home sparkling\nclean and ready for you to occupy.', 'move-in-cleaning.jpg', 1, '2023-07-17', '2023-07-18 12:51:22', '2023-07-20 10:52:27', 0, 0, 0, 0),
(4, 'Floor sanding', 'A company\'s image can rest on the cleanliness of its building. Clean, shiny floors\r\ncan project a positive image, while also providing a safe work environment. Floor\r\nmachines can assist with cleaning industrial and distribution facilities, coating\r\nfloors, and maintaining the overall appearance of a building.', 'floor-sanding2.jpg', 1, '2023-07-20', '2023-07-20 11:01:31', '2023-07-20 11:01:31', 0, 0, 0, 0),
(5, 'Bathroom Cleaning', 'Deodorize and disinfect all areas including\r\nscrubbing clean sink, tub, shower, shelving and floor. Polish all chrome and\r\nglass.', 'bathroom-cleaning.jpg', 1, '2023-07-20', '2023-07-20 11:01:31', '2023-07-20 11:01:31', 0, 0, 0, 0),
(6, 'Kitchen Cleaning', 'Wipe clean all surfaces including interiors of\r\ncabinets, drawers and appliances. After we leave, you can stock the\r\nperfectly clean shelves and refrigerator.\r\n', 'kitchen-cleaning.jpg', 1, '2023-07-20', '2023-07-20 11:01:31', '2023-07-20 11:01:31', 0, 0, 0, 0),
(7, 'General Cleaning', 'Vacuum and/or wash of floors; clean inside all\r\nclosets. Wash windows, sills, remove dust from all baseboards, trim etc.', 'general-cleaning.jpg', 1, '2023-07-20', '2023-07-20 11:01:31', '2023-07-20 11:01:31', 0, 0, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedbackId`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`postId`),
  ADD KEY `adminId` (`adminId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedbackId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `postId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
