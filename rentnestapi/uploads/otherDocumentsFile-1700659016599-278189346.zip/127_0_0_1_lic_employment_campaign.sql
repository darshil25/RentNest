--
-- Database: `lic_employment_campaign`
--
CREATE DATABASE IF NOT EXISTS `lic_employment_campaign` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `lic_employment_campaign`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminId` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `name` varchar(20) NOT NULL,
  `profile` varchar(30) NOT NULL,
  `mobileNumber` varchar(15) NOT NULL,
  `roleId` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `delete` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminId`, `email`, `password`, `name`, `profile`, `mobileNumber`, `roleId`, `status`, `created`, `updated`, `delete`) VALUES
(1, 'licemployment@gmail.com', '202cb962ac59075b964b07152d234b70', 'licemployment', '', '9876543210', 1, 0, '2023-08-08 07:01:21', '2023-08-08 08:55:33', 0),
(2, 'test000@gmail.com', '04d225ce1e6d959c725fa5a0feaf1609', 'Admin', '', '9513578520', 2, 0, '2023-08-08 10:45:42', '2023-08-08 10:48:05', 0);

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `blogId` int(11) NOT NULL,
  `title` varchar(30) NOT NULL,
  `description` text NOT NULL,
  `image` text NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `delete` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`blogId`, `title`, `description`, `image`, `created`, `updated`, `delete`) VALUES
(1, 'Dummy Blog', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'Best-LIC-Guaranteed-Return-Plans (1).png', '2023-08-19 09:42:47', '2023-08-19 09:42:47', 0),
(2, 'Blog', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'Best-LIC-Guaranteed-Return-Plans (1).png', '2023-08-19 09:42:45', '2023-08-19 09:42:45', 0),
(3, 'LIC Agents', 'The job and life of an LIC insurance advisor/agent is never dull. The nature of LIC agent job is free of a repetitive daily routine and requires the agent to interact with new people every day. For the people who are good at communication with associates and strangers alike, this job is very easy and full of opportunities. Not just do you get an exciting job, you can choose your hours of work. You can choose whether to be a full-time agent or do the job as a secondary one. You are free to do the job in your time and your own way, as long as you get results. Along with the flexible timings, the job offers good pay and a lot of perks.', 'Best-LIC-Guaranteed-Return-Plans (1).png', '2023-08-19 09:42:24', '2023-08-19 09:42:24', 0),
(4, 'Lic', 'The job and life of an LIC insurance advisor/agent is never dull. The nature of LIC agent job is free of a repetitive daily routine and requires the agent to interact with new people every day. For the people who are good at communication with associates and strangers alike, this job is very easy and full of opportunities. Not just do you get an exciting job, you can choose your hours of work. You can choose whether to be a full-time agent or do the job as a secondary one. You are free to do the job in your time and your own way, as long as you get results. Along with the flexible timings, the job offers good pay and a lot of perks.', 'Best-LIC-Guaranteed-Return-Plans (1).png', '2023-08-19 10:19:00', '2023-08-19 10:19:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `menuId` int(11) NOT NULL,
  `mainMenuId` int(11) NOT NULL,
  `menuName` varchar(100) NOT NULL,
  `path` varchar(100) NOT NULL,
  `icon` varchar(100) NOT NULL,
  `order` int(11) NOT NULL,
  `add` varchar(4) NOT NULL,
  `edit` varchar(4) NOT NULL,
  `view` varchar(4) NOT NULL,
  `visibility` varchar(4) NOT NULL,
  `delete` varchar(4) NOT NULL,
  `addPath` varchar(100) NOT NULL,
  `deleteMenu` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`menuId`, `mainMenuId`, `menuName`, `path`, `icon`, `order`, `add`, `edit`, `view`, `visibility`, `delete`, `addPath`, `deleteMenu`) VALUES
(1, 0, 'Dashboard', '../dashboard/', 'dashboard', 1, 'NO', 'NO', 'YES', '', 'NO', '', 0),
(2, 0, 'Utility', '', 'format_list_bulleted\r\n', 2, 'NO', 'NO', 'NO', '', 'NO', '', 0),
(3, 0, 'Master', '', 'dashboard', 3, 'NO', 'NO', 'YES', '', 'NO', '', 1),
(4, 2, 'Admin', '../viewadmin/', '', 1, 'YES', 'YES', 'YES', '', 'YES', '../addadmin/', 0),
(5, 2, 'Role', '../viewrole/', '', 2, 'YES', 'YES', 'YES', '', 'YES', '../addrole/', 0),
(6, 0, 'Blog', '../viewblog/', 'rate_review', 4, 'YES', 'YES', 'YES', '', 'YES', '../addblog/', 0);

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `roleId` int(11) NOT NULL,
  `roleName` varchar(30) NOT NULL,
  `encryptId` varchar(30) NOT NULL,
  `menuIdAdd` text NOT NULL,
  `menuIdEdit` text NOT NULL,
  `menuIdDelete` text NOT NULL,
  `menuIdView` text NOT NULL,
  `delete` tinyint(4) NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`roleId`, `roleName`, `encryptId`, `menuIdAdd`, `menuIdEdit`, `menuIdDelete`, `menuIdView`, `delete`, `created`, `updated`) VALUES
(1, 'Super Admin', 'MQ==', '7,16,11,6,10,15,14,3,4', '7,16,11,12,6,10,15,14,3,4', '7,16,11,12,13,6,10,15,14,3,4', '1,7,16,5,2,11,12,13,6,10,15,14,3,4', 0, '2021-11-30 16:04:51', '2022-12-06 13:47:28'),
(2, 'Admin', 'Mg==', '3,4', '3,4', '3,4', '1,2,3,4', 0, '2021-11-30 16:04:51', '2023-07-06 16:56:00'),
(4, 'Developer', 'NA==', '2', '2', '', '1,2', 1, '2021-11-30 16:04:51', '2022-12-06 13:47:28'),
(11, ' Developer', '', '', '', '', '1,2,3,4', 1, '2022-08-05 10:15:26', '2022-12-06 13:47:28'),
(10, 'TEST', '', '', '', '', '', 1, '2022-08-05 10:15:13', '2022-12-06 13:47:28'),
(12, 'Editor ', '', '14,4', '8,5', '', '1,8,5,2,14,3,4', 0, '2022-12-13 15:20:00', '2022-12-13 15:23:18'),
(13, 'Sub editor', '', '', '', '', '', 1, '2022-12-13 15:28:43', '2022-12-13 15:31:48'),
(14, 'Test Admin15216', '', '8', '8', '8', '1,3,8,2,4,5', 1, '2023-07-18 17:38:08', '2023-08-08 16:11:14'),
(15, 'Test admin', '', '', '', '', '', 1, '2023-08-08 16:00:38', '2023-08-08 16:00:49'),
(16, 'Main Admin1', '', '', '', '', '', 1, '2023-08-08 16:11:28', '2023-08-08 16:14:58'),
(17, 'sdfdsgfdsh', '', '', '', '', '', 0, '2023-08-08 16:15:05', '2023-08-08 16:15:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminId`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`blogId`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`menuId`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`roleId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adminId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `blogId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `menuId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `roleId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
